import React from 'react';

const Profile = () =>{
    return(
        <div>
            <h1>Profile page</h1>
            <p>This is profile page</p>
        </div>
    );
};

export default Profile;